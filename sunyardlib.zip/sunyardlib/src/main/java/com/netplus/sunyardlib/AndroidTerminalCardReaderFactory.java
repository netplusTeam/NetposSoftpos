package com.netplus.sunyardlib;

public abstract class AndroidTerminalCardReaderFactory<T> {
    /**
     * @param amount         Amount to be charged
     * @param cashBackAmount Cash Back amount if applicable else pass 0.
     * @param clearKeyPin    Encryption key downloaded during NIBSS initialization.
     */
    public abstract T initiateICCCardPayment(long amount, long cashBackAmount, String clearKeyPin);

    /*
     * method called after initiateICCCardPayment to scan for cards.
     * */
    protected abstract void scanForCard();

    /**
     * @param cardReadResult object that holds the data obtained from the card, will be updated with
     *                       the encrypted pinblock from the pinpad.
     */
    protected abstract void showPinPad(CardReadResult cardReadResult);

    /*
     * method called after a card has been detected to read data from the detected card.
     * */
    protected abstract void readCard();

    protected abstract void updateICCardData(int cardReadResultCode);
}
