package com.netplus.exceptions;

public class KeyManagementException extends Exception {

    public KeyManagementException(String message) {
        super(message);
    }
}
