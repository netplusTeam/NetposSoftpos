package com.sunyard.i80.util;

/**
 * Created by Alex on 2017/7/26.
 */

public class Keys {
    public static String mainKeyDefault = "EC36172A8816B9E5FAB5377C0C48AF6F";
    public static String workKeyDefault = "60F94A439C90E08F187F1E7E686D06C9";
    public static String desKeyDefault = "00112233445566778899AABBCCDDEEFF";
// public static String desKeyDefault = "F1FB6F0DFC843282B4E96075D709E3A3";
//    public static String dukptKeyDefault = "EBDAD9945C7BAACB199A1A5D5A98BB12";

    public static String mainKeyCurrent = "EC36172A8816B9E5FAB5377C0C48AF6F";
    public static String workKeyCurrent = "60F94A439C90E08F187F1E7E686D06C9";
    public static String desKeyCurrent = "00112233445566778899AABBCCDDEEFF";
//    public static String dukptKeyCurrent = "EBDAD9945C7BAACB199A1A5D5A98BB12";

    public Keys(){
    }
}
