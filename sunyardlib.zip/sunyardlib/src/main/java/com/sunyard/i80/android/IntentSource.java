package com.sunyard.i80.android;

public enum IntentSource {

  NATIVE_APP_INTENT,
  PRODUCT_SEARCH_LINK,
  ZXING_LINK,
  NONE

}
